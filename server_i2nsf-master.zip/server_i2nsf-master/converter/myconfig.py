# myconfig.py:

## Converter config
converter=True


## Fortinet config
host="192.168.159.15"
user="admin"
password="admin"
