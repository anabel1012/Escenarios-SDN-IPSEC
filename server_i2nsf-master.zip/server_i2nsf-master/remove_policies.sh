#!/bin/bash

sudo ip xfrm state deleteall
sudo ip xfrm policy deleteall
